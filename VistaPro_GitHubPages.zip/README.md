# Vista Pro Academy — GitHub Pages website
Files included:
- index.html
- register.html (edit the GOOGLE_FORM_LINK placeholder to your Google Form link)
- course.html
- trainer.html
- contact.html
- style.css
- script.js

## How to publish on GitHub Pages (quick)
1. Create a GitHub account (if you don't have one).
2. Create a new repository named exactly: vistaproacademy.github.io
3. Upload all files in this folder to the repository root.
4. Commit and push (or use GitHub's upload UI).
5. Visit: https://vistaproacademy.github.io  (your site should appear).

## Important: Google Form for registrations
- Open Google Forms and create a form with the fields: Name, Email, Phone, Status, Goal.
- In the form 'Send' -> click the link icon to copy the public URL.
- Edit register.html and replace the string GOOGLE_FORM_LINK with your Google Form's URL.
- Use Google Forms + Google Sheets + "Email Notifications for Google Forms" add-on to auto-email Zoom link.

## Need help?
If you'd like, I can:
- Create the Google Form for you and configure auto-email (free).
- Or guide you with step-by-step screenshots.
